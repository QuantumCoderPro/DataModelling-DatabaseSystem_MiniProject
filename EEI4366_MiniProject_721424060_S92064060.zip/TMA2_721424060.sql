-- 721424060_S92064060_TMA 02

-- task 1: create database and tables
-- task2: database populations

DROP DATABASE IF EXISTS suwapiyasa;

CREATE DATABASE suwapiyasa;
USE suwapiyasa;

-- Create the staff table
CREATE TABLE staff (
  EmployeeNumber INT PRIMARY KEY,
  Name VARCHAR(255) NOT NULL,
  Gender VARCHAR(10) NOT NULL,
  Address VARCHAR(255) NOT NULL,
  TelephoneNumber VARCHAR(20) NOT NULL,
  Salary DECIMAL(10, 2),
  UNIQUE (TelephoneNumber)
);

-- Insert data into the staff table
INSERT INTO staff (EmployeeNumber, Name, Gender, Address, TelephoneNumber, Salary) VALUES
  (1, 'Safran', 'Male', 'Main street, Pottuvil', '721424060', 20000.00),
  (2, 'Faiz', 'Male', 'Main street, Akkaraipatru', '721468585', 18000.00),
  (3, 'Kasun', 'Male', 'Colombo', '621452060', 25000.00),
  (4, 'Kethu', 'Female', 'Jafna', '258582323', 30000.00),
  (5, 'Emily', 'Female', '32,colombo-12', '621458282', 35000.00),
  (6, 'Azam', 'Male', 'Pottuvil', '121548585', 32000.00),
  (7, 'Sulakshana', 'Female', '112,colombo-07', '125456565', 38000.00),
  (8, 'Umasuthan', 'Male', 'Batticaloa', '129898145', 200000.00),
  (9, 'Fernando', 'Male', 'Colombo', '129898745', 300000.00),
  (10, 'Marasingha', 'Male', 'Kandy', '129898112', 250000.00);
  
-- output
select *from staff;


-- Create the doctor table
CREATE TABLE doctor (
  EmployeeNumber INT PRIMARY KEY,
  Speciality VARCHAR(255) NOT NULL,
  HDNumber INT,
  FOREIGN KEY (EmployeeNumber) REFERENCES staff (EmployeeNumber),
  FOREIGN KEY (HDNumber) REFERENCES staff (EmployeeNumber)
);

-- Insert data into the doctor table
INSERT INTO doctor (EmployeeNumber, Speciality, HDNumber) VALUES
  (1, 'General', 2),
  (2, 'General', NULL),
  (3, 'Pediatrics', 2),
  (4, 'Urology', 2);
  
  -- output
  select *from doctor;

-- Create the nurse table
CREATE TABLE nurse (
  EmployeeNumber INT PRIMARY KEY,
  Name VARCHAR(255) NOT NULL,
  Gender VARCHAR(10) NOT NULL,
  Address VARCHAR(255) NOT NULL,
  TelephoneNumber VARCHAR(20) NOT NULL,
  Salary DECIMAL(10, 2),
  Grade VARCHAR(10),
  YearsOfExperience INT,
  SurgerySkillType VARCHAR(255),
  FOREIGN KEY (EmployeeNumber) REFERENCES staff (EmployeeNumber)
);

-- Insert data into the nurse table
INSERT INTO nurse (EmployeeNumber, Name, Gender, Address, TelephoneNumber, Salary, Grade, YearsOfExperience, SurgerySkillType) VALUES
  (5, 'Emily', 'Female', '32,colombo-12', '621458282', 35000.00, 'senior', 5, 'General surgery'),
  (6, 'Azam', 'Male', 'Pottuvil', '121548585', 32000.00, 'junior', 2, 'Cardiac surgery'),
  (7, 'Sulakshana', 'Female', '112,colombo-07', '125456565', 38000.00, 'senior', 5, 'Orthopedic surgery');

-- output
select *from nurse;


-- Create the surgeons table
CREATE TABLE surgeons (
  EmployeeNumber INT PRIMARY KEY,
  Name VARCHAR(255) NOT NULL,
  Gender VARCHAR(10) NOT NULL,
  Address VARCHAR(255) NOT NULL,
  TelephoneNumber VARCHAR(20) NOT NULL,
  Speciality VARCHAR(255) NOT NULL,
  ContractType VARCHAR(20),
  ContractLength INT,
  FOREIGN KEY (EmployeeNumber) REFERENCES staff (EmployeeNumber)
);

-- Insert data into the surgeons table
INSERT INTO surgeons (EmployeeNumber, Name, Gender, Address, TelephoneNumber, Speciality, ContractType, ContractLength) VALUES
  (8, 'Umasuthan', 'Male', 'Batticaloa', '129898145', 'Neurology', 'Temporary', 2),
  (9, 'Fernando', 'Male', 'Colombo', '129898745', 'Cardiology', 'Temporary', 1),
  (10, 'Marasingha', 'Male', 'Kandy', '129898112', 'Urology', 'Permanent', NULL);
  
  -- output
  select *from surgeons;
  
-- create the patient table
CREATE TABLE patient (
  PatientID INT PRIMARY KEY,
  Name VARCHAR(255) NOT NULL,
  Age INT,
  Address VARCHAR(255) NOT NULL,
  TelephoneNumber VARCHAR(20) NOT NULL,
  BloodType VARCHAR(10),
  Allergies VARCHAR(255)
);

-- Insert data into the patient table
INSERT INTO patient (PatientID, Name, Age, Address, TelephoneNumber, BloodType, Allergies) VALUES
  (1011,'kalith', 35, 'Batticaloa', '0725454899', 'A+', 'Penicillin'),
  (1012,'kanishka', 45, 'Anuradhapura', '0758585966', 'B-', 'Penicillin'),
  (1013,'bhadiya', 28, 'Panama', '0773232556', 'O+', 'Aspirin');
  
-- output
select *from patient;
  
-- Create the allergies table
CREATE TABLE allergies (
  AllergyID INT PRIMARY KEY,
  PatientID INT,
  AllergyName VARCHAR(255),
  FOREIGN KEY (PatientID) REFERENCES patient (PatientID)
);

-- Insert data into the allergies table
INSERT INTO allergies (AllergyID, PatientID, AllergyName) VALUES
  (501, 1011, 'Penicillin'),
  (502, 1012, 'Penicillin'),
  (503, 1013, 'Aspirin');
  
-- Output
select *from allergies;
  
-- Create the medication table
CREATE TABLE medication (
  Code INT PRIMARY KEY,
  PatientID INT,
  Name VARCHAR(255) NOT NULL,
  QuantityonHand INT,
  QuantityOrdered INT,
  Cost DECIMAL(10, 2),
  ExpirationDate DATE,
  FOREIGN KEY (PatientID) REFERENCES patient (PatientID)
);

-- Insert data into the medication table
INSERT INTO medication (Code,PatientID, Name, QuantityonHand, QuantityOrdered, Cost, ExpirationDate) VALUES
  (301,1011, 'Paracetamol', 100, 50, 10.00, '2024-06-30'),
  (302,1012,'Amoxicillin', 50, 25, 15.00, '2023-09-02'),
  (303,1013, 'Aspirin', 75, 30, 8.50, '2024-09-22');

-- output
select *from medication;
  
-- Create the location table
CREATE TABLE location (
  LocationID INT PRIMARY KEY,
  BedNumber INT,
  RoomNumber INT,
  NursingUnit VARCHAR(255)
);

-- Insert data into the location table
INSERT INTO location (LocationID, BedNumber, RoomNumber, NursingUnit) VALUES
  (201, 101, 1, 'General Ward'),
  (202, 202, 5, 'ICU'),
  (203, 303, 3, 'Pediatric Ward');

-- output
select *from location;
  
-- Create the theatre table
CREATE TABLE theatre (
  TheatreID INT PRIMARY KEY,
  LocationID INT,
  FOREIGN KEY (LocationID) REFERENCES location (LocationID)
);

-- Insert data into the theatre table
INSERT INTO theatre (TheatreID, LocationID) VALUES
  (111, 201),
  (222, 202),
  (333, 203);

-- output
select *from theatre;
  
-- Create the surgery table
CREATE TABLE surgery (
  SurgeryID INT PRIMARY KEY,
  PatientID INT,
  SurgeryName VARCHAR(255) NOT NULL,
  Date DATE,
  Time TIME,
  Category VARCHAR(255),
  SpecialNeeds VARCHAR(255),
  SurgeonID INT,
  TheatreID INT,
  FOREIGN KEY (PatientID) REFERENCES patient (PatientID),
  FOREIGN KEY (SurgeonID) REFERENCES surgeons (EmployeeNumber),
  FOREIGN KEY (TheatreID) REFERENCES theatre (TheatreID)
);

-- Insert data into the surgery table
INSERT INTO surgery (SurgeryID, PatientID, SurgeryName, Date, Time, Category, SpecialNeeds, SurgeonID, TheatreID) VALUES
  (6011, 1011, 'Neurology surgery', '2023-08-15', '10:00:00', 'General Surgery', NULL, 8, 111),
  (6022, 1012, 'Cardiac Bypass', '2023-05-20', '09:30:00', 'Cardiac Surgery', 'Heart condition', 9, 222),
  (6033, 1013, 'urology surgeory', '2023-07-05', '14:00:00', 'Orthopedic Surgery', NULL, 10, 333);

-- output
select *from surgery;
