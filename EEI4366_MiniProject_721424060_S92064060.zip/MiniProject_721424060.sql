-- 721424060_S92064060
-- Mini_Project

USE suwapiyasa;

-- Q1_721424060
CREATE VIEW PatientSurgeryView AS
SELECT 
    p.PatientID,
    CONCAT(SUBSTRING(p.Name, 1, 1), '.', SUBSTRING_INDEX(p.Name, ' ', -1)) AS PatientName,
    CONCAT(l.BedNumber, ' - ', l.RoomNumber) AS Location,
    s.SurgeryName,
    s.Date AS SurgeryDate
FROM patient p
JOIN surgery s ON p.PatientID = s.PatientID
JOIN theatre t ON s.TheatreID = t.TheatreID
JOIN location l ON t.LocationID = l.LocationID;

-- Retrive data from PatientSurgeryView
SELECT * FROM PatientSurgeryView;

-- Q2_721424060_
-- Create table called MedInfo and use triggers
CREATE TABLE MedInfo(
MedName VARCHAR(255) PRIMARY KEY,
QuantityAvailable INT,
ExpirationDate DATE
);

-- Q2_1
-- Use Trigger for inserting into MedInfo
DELIMITER //
CREATE TRIGGER MedInfo_Insert
AFTER INSERT ON medication
FOR EACH ROW
BEGIN
  INSERT INTO MedInfo (MedName, QuantityAvailable, ExpirationDate)
  VALUES (NEW.Name, NEW.QuantityonHand, NEW.ExpirationDate);
END;
//

-- Q2_2
-- Trigger for updating MedInfo
DELIMITER //
CREATE TRIGGER MedInfo_Update
AFTER UPDATE ON medication
FOR EACH ROW
BEGIN
  UPDATE MedInfo
  SET QuantityAvailable = NEW.QuantityonHand, ExpirationDate = NEW.ExpirationDate
  WHERE MedName = NEW.Name;
END;
//

-- Q2_3
-- Trigger for deleting from MedInfo
DELIMITER //
CREATE TRIGGER MedInfo_Delete
AFTER DELETE ON medication
FOR EACH ROW
BEGIN
  DELETE FROM MedInfo WHERE MedName = OLD.Name;
END;
//
DELIMITER ;

-- Q3_721424060
-- Create Stored procedure to take medication count
DELIMITER //
CREATE procedure GetMedicationCount(
	IN p_PatienID INT,
    INOUT p_MedicationCount INT 
)
BEGIN
	SELECT COUNT(*) INTO p_MedicationCount
    FROM medication m
    WHERE m.PatientID = p_PatienID;
END //
DELIMITER ;   

-- To execute the SP
SET @medCount = 0;

-- call SP with patient id and session variable
CALL GetMedicationCount(1012, @medCount);

-- displaying
SELECT @medCount AS MedicationCount;


-- set error code 1418
SET GLOBAL log_bin_trust_function_creators = 1;

-- Q4_721424060
-- function to calculate the number of days remaining for the expiration of a medication
DELIMITER //
CREATE FUNCTION CalculateDaysRemaining(expirationDate DATE, currentDate DATE)
RETURNS int
BEGIN
	DECLARE remainingDays INT;
    SET remainingDays = datediff(expirationDate, currentDate);
    RETURN remainingDays;
END //
DELIMITER ;

-- retrive information
SELECT
	m.Code,
    m.Name,
    m.QuantityonHand,
    m.QuantityOrdered,
    m.Cost,
    m.ExpirationDate,
    CalculateDaysRemaining(m.ExpirationDate, CURDATE()) as DaysRemaining
FROM medication m 
WHERE CalculateDaysRemaining(m.ExpirationDate, CURDATE()) < 30;


-- Q5_721424060
-- Create XML file and load to the database

-- load Staff xml data
LOAD XML INFILE "S:/EEI4366_MINI PROJECT_721424060/Staff.xml"
INTO TABLE suwapiyasa.staff
ROWS IDENTIFIED BY '<staff>';

-- LOAD DATA
SELECT *FROM staff;

-- load Patient xml data
LOAD XML INFILE "S:/EEI4366_MINI PROJECT_721424060/Patient.xml"
INTO TABLE suwapiyasa.patient
ROWS IDENTIFIED BY '<patient>';

-- LOAD DATA patient
SELECT *FROM patient;

